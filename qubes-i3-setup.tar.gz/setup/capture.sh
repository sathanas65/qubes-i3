#!/bin/bash
# capture.sh - snapshot the dom0 files listed in manifest.txt into a tarball
# laid out like this repo, and send it to a qube (dom0 -> qube is the safe direction).
#
#   bash ~/capture.sh [qube]        (default qube: personal)
#
# Then, in that qube:
#   tar -xzf ~/QubesIncoming/dom0/dom0-capture-*.tar.gz -C ~/qubes-i3
#   cd ~/qubes-i3 && git status && git add -A && git commit -m "dom0 snapshot" && git push

set -u
QUBE=${1:-personal}
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
MANIFEST="$HERE/manifest.txt"
[ -f "$MANIFEST" ] || { echo "no manifest.txt next to this script" >&2; exit 1; }
command -v qvm-copy-to-vm >/dev/null || { echo "run this in dom0" >&2; exit 1; }

STAGE=$(mktemp -d); trap 'rm -rf "$STAGE"' EXIT
OUT="$HOME/dom0-capture-$(date +%F-%H%M).tar.gz"

while IFS= read -r line; do
    line=${line%%#*}
    line="${line#"${line%%[![:space:]]*}"}"; line="${line%"${line##*[![:space:]]}"}"
    [ -n "$line" ] || continue
    as=''
    case $line in
        /etc/*)    src=$line;           dest="etc/${line#/etc/}"; as=sudo ;;
        .config/*) src="$HOME/$line";   dest="config/${line#.config/}" ;;
        .local/*)  src="$HOME/$line";   dest="local/${line#.local/}" ;;
        scripts|scripts/*) src="$HOME/$line"; dest=$line ;;
        *)         src="$HOME/$line";   dest="home/$line" ;;
    esac
    if [ ! -e "$src" ]; then echo "skip (not found): $line" >&2; continue; fi
    mkdir -p "$STAGE/$(dirname "$dest")"
    $as cp -a "$src" "$STAGE/$dest"
done < "$MANIFEST"
sudo chown -R "$(id -u):$(id -g)" "$STAGE" 2>/dev/null
find "$STAGE" -name .git -prune -exec rm -rf {} + 2>/dev/null

# Public repo? Flag anything that looks like a secret before it leaves dom0.
hits=$(grep -rIliE 'api[_-]?key|passw(or)?d|secret|token|BEGIN [A-Z ]*PRIVATE KEY' "$STAGE" 2>/dev/null)
if [ -n "$hits" ]; then
    echo "!! These files mention keys/passwords/tokens - check before pushing to a public repo:" >&2
    echo "$hits" | sed "s|$STAGE/|   |" >&2
fi

tar -czf "$OUT" -C "$STAGE" .
echo "Wrote $OUT ($(du -h "$OUT" | cut -f1))"
qvm-copy-to-vm "$QUBE" "$OUT" && echo "Sent to $QUBE -> ~/QubesIncoming/dom0/$(basename "$OUT")"
