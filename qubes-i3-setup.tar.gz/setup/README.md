# dom0 setup

**Master copy lives in a qube** (this repo). dom0 only pulls from it.

## Set up a fresh dom0
In the qube (`personal`): `git clone https://github.com/sathanas65/qubes-i3 ~/qubes-i3`  (or `git pull`).

In dom0:
```
mkdir -p ~/import && rm -rf ~/import/qubes-i3
qvm-run -p personal 'tar -C ~ --exclude=.git -cf - qubes-i3' | tar -C ~/import -xf -
less ~/import/qubes-i3/setup/install.sh        # read it - it runs in dom0
bash ~/import/qubes-i3/setup/install.sh --dry-run
bash ~/import/qubes-i3/setup/install.sh
```

## Save changes made in dom0
```
bash ~/import/qubes-i3/setup/capture.sh personal
```
then unpack and commit in the qube (the script prints the commands).

## Layout
config/ -> ~/.config   local/ -> ~/.local   home/ -> ~   scripts/ -> ~/scripts   etc/ -> /etc
